const { SelectControl } = wp.components;
const { withSelect } = wp.data;

export const ArticleSelect = ( { posts, value, onChange } ) => {
	const options = [];

	// if posts found
	if ( posts ) {
		options.push( { value: 0, label: 'Select something' } );
		posts.forEach( ( post ) => { // simple foreach loop
			options.push( { value: post.id, label: post.title.rendered } );
		} );
	} else {
		options.push( { value: 0, label: 'Loading...' } );
	}
	return (
		<SelectControl
			label="Select a Article"
			value={ value }
			options={ options }
			onChange={ onChange }
		/>
	);
};

export const SelectElement = withSelect( ( select ) => ( {
	posts: select( 'core' ).getEntityRecords( 'postType', 'post' ),
} ) )( ArticleSelect );

const ARTICLE_QUERY = `
query Article($id: Int) {
	postBy(postId: $id) {
	__typename
	  title
	  id
	  date
	  slug
	  desiredSlug
      excerpt
      coAuthors {
        id
        display_name
        slug
        bio
        avatar
        reporter_title
      }
      featuredImage {
        sourceUrl
        altText
      }
      categories {
        nodes {
          name
          slug
        }
      }
    }
    
}
`;

export const authorNames = ( authors ) => authors.map( function( author ) {
	return author.display_name;
} ).join( ' , ' ) + ' ' + roles( authors );

export const roles = ( authors ) => authors.map( function( author ) {
	return author.reporter_title;
} ).join( ' ' );

export const fetchPost = async( postId ) => {
	const response = await fetch( '/graphql', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
		body: JSON.stringify( {
			query: ARTICLE_QUERY,
			variables: {
				id: postId,
			},
		} ),
	} );
	return await response.json();
};

const FEATURED_ARTICLES = `
query FeaturedArticles {
	tag(id: "cG9zdF90YWc6NQ==") {
		name
		  posts(first:5, where: { orderby: { field: DATE, order: DESC } }) {
		  nodes {
			title
			slug
			date
			coAuthors {
			  display_name
			  reporter_title
			  id
			}
			categories {
				nodes {
				  name
				  slug
				}
			  }
		  }
		}
	  }
  }
`;

export const fetchFeatured = async( ) => {
	const response = await fetch( '/graphql', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
		body: JSON.stringify( {
			query: FEATURED_ARTICLES,
		} ),
	} );
	return await response.json();
};
