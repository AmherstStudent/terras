/**
 * BLOCK: article-text-row
 *
 * Registering a basic block with Gutenberg.
 * Simple block, renders and saves the same content without any interactivity.
 */

//  Import CSS.
import { SelectElement, fetchPost, authorNames } from '../selectArticle';
import './editor.scss';
import HeroImage from './HeroImage';

const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks
const { InspectorControls } = wp.blockEditor;
const { PanelBody } = wp.components;

/**
 * Register: aa Gutenberg Block.
 *
 * Registers a new block provided a unique name and an object defining its
 * behavior. Once registered, the block is made editor as an option to any
 * editor interface where blocks are implemented.
 *
 * @link https://wordpress.org/gutenberg/handbook/block-api/
 * @param  {string}   name     Block name.
 * @param  {Object}   settings Block settings.
 * @return {?WPBlock}          The block, if it has been successfully
 *                             registered; otherwise `undefined`.
 */

registerBlockType( 'home/hero-image', {
	// Block name. Block names must be string that contains a namespace prefix. Example: my-plugin/my-custom-block.
	title: __( 'Basic Hero Image' ), // Block title.
	icon: 'format-aside', // Block icon from Dashicons → https://developer.wordpress.org/resource/dashicons/.
	category: 'common', // Block category — Group blocks together based on common traits E.g. common, formatting, layout widgets, embed.
	keywords: [
		__( 'base-article-box' ),
		__( 'create-guten-block' ),
	],
	attributes: {
		postID: {
			type: 'string',
			default: 'none',
		},
		category: {
			type: 'string',
			default: 'none',
		},
		category_slug: {
			type: 'string',
			default: 'none',
		},
		title: {
			type: 'string',
			default: 'none',
		},
		authors: {
			type: 'array',
			default: [],
		},
		featuredImageUrl: {
			type: 'string',
			// Add a default image!
		},
		featuredImageAlt: {
			type: 'string',
		},
		excerpt: {
			type: 'string',
			default: 'none',
		},
		issue: {
			type: 'string',
			default: 'none',
		},
		date: {
			type: 'string',
		},
		slug: {
			type: 'string',
		}
	},

	/**
	 * The edit function describes the structure of your block in the context of the editor.
	 * This represents what the editor will render when the block is used.
	 *
	 * The "edit" property must be a valid function.
	 *
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 *
	 * @param {Object} props Props.
	 * @returns {Mixed} JSX Component.
	 */
	edit: ( props ) => {
		const { attributes: { postID, title, date, authors, category, featuredImageAlt, featuredImageUrl, slug },
			setAttributes } = props;

		const setArticle = ( id ) => {
			fetchPost( id ).then( response => {
				const post = response.data.postBy;
				setAttributes( {
					postID: id,
					title: post.title,
					category: post.categories.nodes[ 0 ].name,
					featuredImageUrl: post.featuredImage && post.featuredImage.sourceUrl,
					authors: post.coAuthors,
					date: post.date,
					excerpt: post.excerpt.replace( /(<([^>]+)>)/ig, '' ),
					slug: post.slug,
				} );
			} );
		};

		return [
			<InspectorControls key="noted">
				<PanelBody title={ 'Articles' }>
					<SelectElement
						value={ postID }
						onChange={ ( value ) => setArticle( value ) } />
				</PanelBody>
			</InspectorControls>,
			<HeroImage
				key="hero"
				title={ title }
				authors={ authors }
				category={ category }
				featuredImage={ { url: featuredImageUrl, alt: featuredImageAlt } }
				date={ date }
			/>,
		];
	},

	/**
	 * The save function defines the way in which the different attributes should be combined
	 * into the final markup, which is then serialized by Gutenberg into post_content.
	 *
	 * The "save" property must be specified and must be a valid function.
	 *
	 * @link https://wordpress.org/gutenberg/handbook/block-api/block-edit-save/
	 *
	 * @param {Object} props Props.
	 * @returns {Mixed} JSX Frontend HTML.
	 */
	save: ( props ) => {
		return (
			<div className={ props.className }>
				<p>— Hello from the frontend.</p>
				<p>
					CGB BLOCK: <code>article-text-row</code> is a new Gutenberg block.
				</p>
				<p>
					It was created via{ ' ' }
					<code>
						<a href="https://github.com/ahmadawais/create-guten-block">
							create-guten-block
						</a>
					</code>.
				</p>
			</div>
		);
	},
} );
