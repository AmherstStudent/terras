import styled from 'styled-components';

const ArticleBlockWrapper = styled.div`
margin-bottom: 20px;
height: 100%;
width:100%;
`;
const Category = styled.a`
font-family: Halyard Text;
font-style: normal;
font-weight: bold;
font-size: 12px;
line-height: 17px;
letter-spacing: 0.05em;
color: #3F1F69;
`;

const ArticleTextContent = styled.div`
margin-top: 20px;
`;
const ArticleTitle = styled.h2`
font-family: Cormorant;
font-style: normal;
font-weight: bold;
font-size: 24px;
line-height: 29px;
color: #000000;
margin-top: 10px;
margin-bottom: 10px;

`;
const ArticleByline = styled.p`
font-family: Halyard Text;
font-style: italic;
font-weight: 300;
font-size: 12px;
line-height: 150%;
margin: 0;
/* or 18px */
color: #595959;
`;
const ArticleBio = styled.p`
font-family: Halyard Text;
font-style: italic;
font-weight: 300;
font-size: 16px;
line-height: 172.1%;
/* or 28px */
color: #080808;
margin: 50px 0 ;

`;
const AuthorUnderline = styled.div`
    margin-top: 10px;
    width: 50px;
    height: 9px;
    background-color: #3F1F69;
    margin: 20px 0;
`;

const AuthorName = styled.a`
font-family: Halyard Text;
font-style: normal;
font-weight: bold;
font-size: 12px;
line-height: 150%;
color: #595959;
text-decoration: none;
text-transform: capitalize;
`;
const formatDate = ( date ) => {
	const updatedDate = new Date( date );
	const options = { year: 'numeric', month: 'long', day: 'numeric' };
	const formattedDate = updatedDate.toLocaleDateString( 'en-US', options );
	return formattedDate;
};
const AuthorNameLink = ( author ) => {
	return ( <span>
		<AuthorName>{ author.display_name }{ ',  ' }</AuthorName>
	</span> );
};

const AuthorNames = ( { authors } ) => authors.map( ( author ) => {
	return ( <AuthorNameLink key={ author.id } { ...author } /> );
} );

const LargeArticleBlock = ( { date, category, authors, title, description } ) => {
	const titles = authors.length > 1 ? authors.map( ( author ) => {
		return ( author.job_title );
	} ).join( ' & ' ) : (authors.length !== 0) && authors[ 0 ].job_title;

	return (
		<ArticleBlockWrapper>
			<ArticleTextContent>
				<Category>{ category }</Category>
				<ArticleTitle>{ title }</ArticleTitle>
				<ArticleByline>by <AuthorNames authors={ authors } /> { titles }</ArticleByline>
				<ArticleByline>{ formatDate( date ) }</ArticleByline>
				<AuthorUnderline />
			</ArticleTextContent>
			<ArticleBio>{ description }</ArticleBio>

		</ArticleBlockWrapper>
	);
};

export default LargeArticleBlock;
