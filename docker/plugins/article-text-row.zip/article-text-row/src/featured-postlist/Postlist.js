import styled from 'styled-components';

const PostWrapper = styled.div`
    border-bottom: 0.5px rgba(0,0,0,0.5) solid;
    padding: 10px 0;
`;
const Category = styled.a`
font-family: Halyard Text;
font-style: normal;
font-weight: bold;
font-size: 12px;
line-height: 17px;
letter-spacing: 0.05em;
text-transform: uppercase;
& > a {
    text-decoration: none;
    color: #3F1F69;
}
`;
const Title = styled.h3`
font-family: Cormorant;
font-style: normal;
font-weight: bold;
font-size: 21px;
line-height: 25px;
margin: 0 !important;

& > a {
    text-decoration: none;
    color: #000000;
}
`;
const Tagline = styled.p`
font-family: Halyard Text;
font-style: italic;
font-weight: 300;
font-size: 12px;
line-height: 150%;
color: #595959;
margin: 5px 0;
`;
const AuthorNames = ( { authors } ) => authors.map( ( author ) => {
	return ( <AuthorNameLink key={ author.id } { ...author } /> );
} );
const formatDate = ( date ) => {
	const updatedDate = new Date( date );
	const options = { year: 'numeric', month: 'long', day: 'numeric' };
	const formattedDate = updatedDate.toLocaleDateString( 'en-US', options );
	return formattedDate;
};
const AuthorNameLink = ( author ) => {
	return ( <span>
		<AuthorName>{ author.display_name }{ ',  ' }</AuthorName>
	</span> );
};

const AuthorName = styled.a`
font-family: Halyard Text;
font-style: normal;
font-weight: bold;
line-height: 150%;
color: #595959;
text-decoration: none;
text-transform: capitalize;
`;

/// STEAL FROM TAGS PAGE
const Post = ( { date, title, authors, category } ) => {
	const titles = authors.length > 1 ? authors.map( ( author ) => {
		return ( author.job_title );
	} ).join( ' & ' ) : ( authors.length !== 0 ) && authors[ 0 ].job_title;

	return (
		<PostWrapper>
			<Category>{ category }</Category>
			<Title>{ title }</Title>
			<Tagline>
            by <AuthorNames authors={ authors } />
				{ titles } || <time>{ formatDate( date ) }</time></Tagline>
		</PostWrapper> );
};
const PostlistWrapper = styled.div`
    height: 100%;

`;
const Postlist = ( { selectedPosts } ) => {
	return (
		<PostlistWrapper>
			{ selectedPosts.map( ( article ) => {
				return ( <Post
					key={ article.date }
					date={ article.date }
					title={ article.title }
					authors={ article.coAuthors }
					category={ article.categories.nodes[ 0 ].name }
					id={ article.id }
					slug={ article.slug } /> );
			} ) }
		</PostlistWrapper>
	);
};

export default Postlist;
