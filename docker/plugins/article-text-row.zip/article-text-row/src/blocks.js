/**
 * Gutenberg Blocks
 *
 * All blocks related JavaScript files should be imported here.
 * You can create a new block folder in this dir and include code
 * for that block here as well.
 *
 * All blocks should be included here since this is the file that
 * Webpack is compiling as the input file.
 */

import './small-article/block.js';
import './large-article/block.js';
import './homepage-quote/block.js';
import './hero-image/block.js';
import './featured-postlist/block.js';

