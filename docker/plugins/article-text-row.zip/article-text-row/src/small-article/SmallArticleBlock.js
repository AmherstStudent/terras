import styled from 'styled-components';

const ArticleBlockWrapper = styled.div`
    display:flex;
    flex-direction: column;
`;
const Category = styled.span`
font-family: Halyard Text;
font-style: normal;
font-weight: bold;
font-size: 12px;
line-height: 17px;
letter-spacing: 0.05em;
color: #3F1F69;
`;
const ArticleImage = styled.img`
max-height:400px;
width: 100%;
object-fit: cover;
`;
const ArticleTextContent = styled.div`
    margin-top: 20px;
`;
const ArticleTitle = styled.h2`
margin:0 !important;
font-family: Cormorant;
font-style: normal;
font-weight: bold;
font-size: 24px;
line-height: 29px;
color: #000000;
margin-top: 10px;
margin-bottom: 10px;

`;
const ArticleByline = styled.p`
font-family: Halyard Text;
font-style: italic;
font-weight: 300;
font-size: 12px;
line-height: 150%;
margin: 0;
/* or 18px */
color: #595959;
`;
const ArticleBio = styled.p`
font-family: Halyard Text;
font-style: italic;
font-weight: 300;
font-size: 16px;
line-height: 172.1%;
/* or 28px */
color: #080808;
`;

const AuthorName = styled.a`
font-family: Halyard Text;
font-style: normal;
font-weight: bold;
line-height: 150%;
color: #595959;
text-decoration: none;
text-transform: capitalize;
`;
const formatDate = ( date ) => {
	const updatedDate = new Date( date );
	const options = { year: 'numeric', month: 'long', day: 'numeric' };
	const formattedDate = updatedDate.toLocaleDateString( 'en-US', options );
	return formattedDate;
};
const AuthorNameLink = ( author ) => {
	return ( <span>
		<AuthorName>{ author.display_name }{ ',  ' }</AuthorName>
	</span> );
};

const AuthorNames = ( { authors } ) => authors.map( ( author ) => {
	return ( <AuthorNameLink key={ author.id } { ...author } /> );
} );

const SmallArticleBlock = ( { authors, title, category, featuredImage, date, description } ) => (
	<ArticleBlockWrapper>
		{ featuredImage.url && <ArticleImage src={ featuredImage.url } /> }
		<ArticleTextContent>
			<Category>{ category }</Category>
			<ArticleTitle>{ title }</ArticleTitle>
			<ArticleByline>by <AuthorNames authors={ authors } /> || { formatDate( date ) }</ArticleByline>
			<ArticleBio>{ description }</ArticleBio>
		</ArticleTextContent>
	</ArticleBlockWrapper>
);

export default SmallArticleBlock;
